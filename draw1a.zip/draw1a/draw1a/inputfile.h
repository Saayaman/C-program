//
//  inputfile.h
//  draw1a
//
//  Created by ayako_sayama on 2017-04-17.
//  Copyright © 2017 ayako_sayama. All rights reserved.
//

#ifndef inputfile_h
#define inputfile_h

#include <stdio.h>

#endif /* inputfile_h */
